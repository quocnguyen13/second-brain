---
type: moc
project: thinking-system
status: active
trust: working
origin: claude
created: 2026-09-16
reviewed: 2026-10-06
tags: [project/thinking-system, moc]
---

# Thinking System: Project Home

> [!abstract] What this is
> A personal knowledge assistant built on the **LLM Wiki** pattern: you collect sources, Claude compiles them into a cited wiki you read in Obsidian, and on top sit a thinking layer you own and, next, defined jobs done to your standards. Where it's going: [[10 Product Vision]]. How it works today: [[20 Product Requirements]].

**Setup:** personal Windows PC · Claude Pro · Claude Code running inside the vault
**Where we are:** MVP 1 done 2026-09-25 (6 of 6). MVP 2 (Research assistant) in progress ([[11 Project Charter]] §11, D-084): **M7 – Batch Ingest and Trust closed 2026-10-06**, tests 7 of 7, with the batch-ingest criterion met ([[88 M7 Handover]]). **M8 – Research and Import started 2026-10-06:** the `research` and `import` skills, the path for Claude outputs through `/ingest`, and twelve tests are written, with D-095 to D-100 waiting for your word ([[21 Roadmap]] §11). The showcase waits for a thinking layer worth showing; you decide after each MVP (D-082).

## Document set
Numbered by SDLC stage, in blocks of ten ([[03 Decision Log]] D-080). A document keeps its number; a new one takes the next free number in its stage. Planned documents have their number reserved, shown in *italics* with the backlog item that writes them. Governance runs through every stage, and every module adds a delivery record.

```mermaid
%%{init: {"flowchart": {"curve": "step", "useMaxWidth": true, "nodeSpacing": 12, "rankSpacing": 25, "padding": 8, "subGraphTitleMargin": {"top": 4, "bottom": 8}}}}%%
flowchart TD
    G["Stage 0 · Governance<br/>docs 00–04"]
    P1["Stage 1 · Plan: strategy<br/>docs 10–13"]
    P2["Stage 2 · Plan: scope<br/>docs 20–22"]
    D["Stage 3 · Design<br/>docs 30–36"]
    B["Stage 4 · Build<br/>doc 40"]
    T["Stage 5 · Test<br/>doc 50"]
    R["Stage 6 · Deploy<br/>doc 60"]
    M["Stage 7 · Maintain<br/>docs 70–71"]
    H["Stage 8 · Records<br/>docs 80 onward"]
    G ~~~ P1
    P1 --> P2 --> D --> B --> T --> R --> M
    M -. "next increment" .-> P2
    R -. "module closes" .-> H
```

### Stage 0 · Governance
| # | Document | Purpose | Status |
|---|---|---|---|
| 00 | [[00 Project Home]] | Map of the project (you are here) | Draft |
| 01 | *Case Study* | The project told for a reader outside it | Planned · B-028 |
| 02 | [[02 Working Agreement]] | Roles, the document loop, module threads, Definition of Done, the delivery framework | **Accepted** |
| 03 | [[03 Decision Log]] | Decisions made and questions still open | Living document |
| 04 | *Risk Register* | Risks, owners and mitigations in one place | Planned · B-033 |

### Stage 1 · Plan: strategy
| # | Document | Purpose | Status |
|---|---|---|---|
| 10 | [[10 Product Vision]] | Who it's for, what they need, how success is measured, milestones and capabilities | Draft |
| 11 | [[11 Project Charter]] | MVP 1: problem, bet, scope, goals, success criteria | **Accepted** |
| 12 | *Success Metrics* | Definitions, baselines and targets per milestone | Planned · B-031 |
| 13 | *Market and Alternatives* | What else meets the same needs, and why this one | Planned · B-032 |

### Stage 2 · Plan: scope
| # | Document | Purpose | Status |
|---|---|---|---|
| 20 | [[20 Product Requirements]] | The whole system for a newcomer: user stories, architecture, flows, data, edge cases | Draft |
| 21 | [[21 Roadmap]] | Modules and their exits | **Accepted** |
| 22 | [[22 Product Backlog]] | Capabilities and features waiting to be scheduled | Draft |

### Stage 3 · Design
| # | Document | Purpose | Status |
|---|---|---|---|
| 30 | [[30 System Architecture]] | The three layers, the three operations, and what we add on top | **Accepted** |
| 31 | [[31 Trust and Provenance]] | Citation rules, page status, the data boundary | **Accepted** |
| 32 | [[32 Vault Blueprint]] | Folders, page types, properties, index and log formats | **Accepted** |
| 33 | [[33 Input Zones]] | One input door per operation, all triggered inside Claude | **Accepted** |
| 34 | [[34 Templates]] | One template per page type, in `system/templates/` | Draft |
| 35 | *Jobs and Standards* | The jobs Claude does and the standards they follow. Replaces the planned Workflow Playbook | Planned · B-017 |
| 36 | *Data Governance* | Rules for work material, before any enters the vault (D-018) | Planned · B-022 |

### Stage 4 · Build
| # | Document | Purpose | Status |
|---|---|---|---|
| 40 | [[40 Claude Operating Instructions]] | `CLAUDE.md`, permission settings, the skills in full, test prompts, setup steps | **Accepted** |

### Stage 5 · Test
| # | Document | Purpose | Status |
|---|---|---|---|
| 50 | *Test Strategy and Results* | Test levels, user stories traced to tests and results. Results today: `system/test-results.md` | Planned · B-034 |

### Stage 6 · Deploy
| # | Document | Purpose | Status |
|---|---|---|---|
| 60 | *Release Notes* | What each milestone shipped, and how it was deployed | Planned · B-035 |

### Stage 7 · Maintain
| # | Document | Purpose | Status |
|---|---|---|---|
| 70 | [[70 Obsidian Essentials]] | The user guide: setup, toolkit, reviewing an ingest, the weekly review | **Accepted** |
| 71 | *Operations Runbook* | Routines, deploy, backup, restore and rollback | Planned · B-036 |

### Stage 8 · Delivery records
Agile reviews and retrospectives, in date order.

| # | Document | Purpose | Status |
|---|---|---|---|
| 80 | [[80 M0 Handover]] | Closing state of M0, used to open the M1 chat | Closed |
| 81 | [[81 M1 Handover]] | Closing state of M1, used to open the M2 chat | Closed |
| 82 | [[82 M2 Handover]] | Closing state of M2, used to open the M3 chat | Closed |
| 83 | [[83 M3 Handover]] | Closing state of M3, used to open the M4 chat | Closed |
| 84 | [[84 M4 Handover]] | Closing state of M4, used to open the M5 chat | Closed |
| 85 | [[85 M5 Handover]] | Closing state of M5, used to open the M6 chat | Closed |
| 86 | [[86 M6 Handover]] | Closing state of M6 and MVP 1, to take to the M0 thread | Closed |
| 87 | [[87 MVP Retrospective]] | Retrospective of MVP 1 and the input to MVP 2's scope | Draft |
| 88 | [[88 M7 Handover]] | Closing state of M7, used to open the M8 chat | Current |

## What the set was missing
Checked on 2026-09-30 against the documents a standard SDLC and a Scrum-style process expect, and against what a reviewer of the showcase would look for.

**Already in place:** requirements with acceptance criteria (20 §3.1, "Done when"), architecture and design (30–34), decision records (03), a working agreement with a Definition of Done (02), increment reviews (80–86), a retrospective (87), test prompts with recorded results (40 §5).

| Expected | Where it was | Gap | Filled by |
|---|---|---|---|
| Product vision | 11 §1, one paragraph | No target group, needs, metrics or milestones | **Done:** doc 10 |
| Delivery framework | Implicit in 02 §4 | Roles, events and artefacts not named | **Done:** 02 §11 |
| Definition of Ready, priority method | — | Missing | **Done:** 22 §1.1–1.2 |
| Backlog structure | A flat list of 3 items | No capabilities, types or milestones | **Done:** 22 §2, 36 items |
| Success metrics | 11 §5, MVP 1 only | No North Star, baselines or targets beyond MVP 1 | Started in 10 §3; doc 12 (B-031) |
| Market and alternatives | — | Missing | Doc 13 (B-032) |
| Risk register | 11 §10 and the handovers | Scattered, not tracked | Doc 04 (B-033) |
| Test strategy and traceability | 40 §5, `system/test-results.md` | No strategy; stories not traced to tests | Doc 50 (B-034) |
| Release notes | The change log below | Tracks documents, not releases | Doc 60 (B-035) |
| Operations runbook | 70 §4, 20 §7, deploy steps in handovers | Scattered; no backup, restore or rollback | Doc 71 (B-036) |
| Output standards | Diagram rules in 02 §8 | No home for the standards jobs will use | Doc 35 (B-017) |
| Data governance | Parked (D-018) | Needed before any work material | Doc 36 (B-022) |
| Case study, public repo, demo | — | Missing, and needed for the showcase | Doc 01, B-029, B-030 |

## Renumber map, 2026-09-30
Every reference in the project docs and vault files now uses the new numbers, except the change log below, which keeps the numbers of its time (D-080).

| Old | New | Document | | Old | New | Document |
|---|---|---|---|---|---|---|
| 00 | 00 | Project Home | | 13 | 33 | Input Zones |
| 01 | 11 | Project Charter | | 14 | 80 | M0 Handover |
| 02 | 30 | System Architecture | | 15 | 81 | M1 Handover |
| 03 | 31 | Trust and Provenance | | 16 | 82 | M2 Handover |
| 04 | 32 | Vault Blueprint | | 17 | 83 | M3 Handover |
| 05 | 70 | Obsidian Essentials | | 18 | 84 | M4 Handover |
| 06 | 21 | Roadmap | | 19 | 85 | M5 Handover |
| 07 | 03 | Decision Log | | 20 | 86 | M6 Handover |
| 08 | 40 | Claude Operating Instructions | | 21 | 87 | MVP Retrospective |
| 09 | 02 | Working Agreement | | 22 | 22 | Product Backlog |
| 10 | 34 | Templates | | 23 | 20 | Product Requirements |
| 11 (planned) | 35 | Workflow Playbook, now Jobs and Standards | | 12 (planned) | 36 | Data Governance |
| — | 10 | Product Vision (new) | | | | |

## Reading order
New to the project? Start with the first two, then go deeper:
1. [[10 Product Vision]]: where the product is going.
2. [[20 Product Requirements]]: the whole system as built.
3. [[02 Working Agreement]]: how we work together.
4. [[11 Project Charter]]: what MVP 1 was and wasn't.
5. [[30 System Architecture]] and [[31 Trust and Provenance]]: the pattern, and what keeps a compiled wiki honest.
6. [[40 Claude Operating Instructions]]: exactly what Claude is told and allowed to do.
7. [[03 Decision Log]]: every decision and why.
8. [[70 Obsidian Essentials]]: the one page of Obsidian you need.

## Origin of the pattern
The foundation is Andrej Karpathy's "LLM Wiki" idea file, at https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f. It was the first source ingested, in M3, so the vault's first pages are about the pattern the vault is built on.

## Learn Obsidian from this document set
These notes use Obsidian's own syntax, so reading them is your first lesson:
- `[[11 Project Charter]]` is a **wikilink**. Click it to jump; the target lists this note under **Backlinks**.
- The block between the `---` lines is **Properties** (YAML frontmatter), shown as an editable table.
- The `> [!abstract]` boxes are **callouts**.
- The diagrams in [[30 System Architecture]] are **Mermaid** code blocks, which Obsidian draws without a plugin.

## Change log

Entries up to 1.35 use the document numbers of their time; the renumber map above translates them.

| Version  | Date       | Changes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| -------- | ---------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 0.1      | 2026-09-16 | First document set (00–07)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
| 0.2      | 2026-09-16 | Claude Code chosen as the main tool; doc 08 added; folders renamed with hyphens                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| 0.3      | 2026-09-16 | Doc 09 Working Agreement added                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 0.4      | 2026-09-16 | Preferences agreed; modules added to the roadmap                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| **1.0**  | 2026-09-18 | **Adopted the LLM Wiki pattern as the foundation.** Vault restructured into `raw/`, `wiki/`, `mine/`; ingest, query, and lint become the core operations; doc 03 narrowed to trust and provenance, with bank data governance parked as doc 12                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| 1.1      | 2026-09-19 | **Documents 00–09 accepted** and promoted to `working`. Doc 13 (Input Zones) added: one input door per operation, all run inside Claude.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| 1.2      | 2026-09-19 | Input zones accepted (D-023 to D-025); draft queue renamed `mine/drafts/`; M0 closed and handover written                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 1.3      | 2026-09-19 | Obsidian curriculum removed (D-026): doc 05 becomes a reference page, goal G5 narrowed to verification (D-027), module estimates cut                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             |
| 1.4      | 2026-09-21 | Documents moved to a private GitHub repo synced into project knowledge (D-028); the repo is now the master copy; Q-014 opened                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| **1.5**  | 2026-09-21 | **M1 closed.** D-026 and D-027 accepted. D-029: your own new notes go to `mine/scratch/`. D-030: the vault repo is the single source of truth, project knowledge syncs `mine/projects/thinking-system/`, and the documents repo is archived (supersedes D-028). Docs 02, 03, 04, 05, 06, 08, 09 and 13 updated to match, including two broken links to the retired 05 Learning Path; doc 15 (M1 Handover) added                                                                                                                                                                                                                                                                                  |
| 1.6      | 2026-09-21 | Doc 15 (M1 Handover) accepted and promoted to `working`                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
| 1.7      | 2026-09-21 | **M2 started.** Schema files created in the vault: `CLAUDE.md`, `.claude/settings.json`, `system/context.md`, `system/conventions.md`, `index.md`, `log.md`, and eight templates. Doc 10 (Templates) added. Tool facts rechecked against the current Claude Code docs; D-031 to D-035 proposed. Docs 04, 06, 08 and 13 updated to match                                                                                                                                                                                                                                                                                                                                                          |
| 1.8      | 2026-09-22 | First Claude Code session: claude.ai connectors, the synced `data` plugin and synced skills found loading into vault sessions. D-036 (connectors off) and D-037 (`data` plugin off) proposed; Q-015 opened (remaining synced skills, due at M3). Docs 06, 07 and 08 updated                                                                                                                                                                                                                                                                                                                                                                                                                      |
| **1.9**  | 2026-09-22 | **M2 closed.** D-031 to D-037 accepted; D-038 added and accepted (stop when a permission rule blocks). All setup checks and the smoke test passed. Docs 06, 07, 08 and `CLAUDE.md` updated; doc 16 (M2 Handover) added                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| 1.10     | 2026-09-22 | Q-013 answered: the first five sources are the LLM-knowledge set (D-039). Docs 07 and 16 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |
| **1.11** | 2026-09-22 | **M3 started.** `ingest` skill drafted (arrives as `ingest-SKILL.md` for you to move into `.claude/skills/ingest/`) and mirrored in doc 08 §4.1; the ingest section of `CLAUDE.md` becomes a pointer. Overview page type and template added. D-040 (answers Q-015) to D-044 proposed. Docs 04, 06, 07, 08, 10 and 13 and `system/conventions.md` updated                                                                                                                                                                                                                                                                                                                                         |
| 1.12     | 2026-09-22 | D-040 to D-044 accepted. Q-015 decided: synced skills hidden in vault sessions, which takes effect once their names are in `.claude/settings.json`. Docs 06, 07 and 08 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   |
| 1.13     | 2026-09-22 | First ingest (LLM Wiki gist) reviewed. `ingest` skill revised: the status rule is clarified (one source can make a page `verified`), links are checked before the report, and the move check uses file tools instead of a shell command. Docs 06 and 08 updated                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| 1.14     | 2026-09-22 | Source 1 committed. The `raw/` deny rule blocked Claude's shell move, so the move becomes yours, with the command given in the skill's first message. D-045 proposed and accepted. Docs 06, 07, 08 and 13 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| 1.15     | 2026-09-22 | Source 2 (As We May Think) ingested. The ingest missed that source 1 already discusses Bush's Memex, so the skill now searches `wiki/` and `raw/` for every new source, and also gets ground rules (file tools only, no working files, no deletions), PDF page citations (D-046, accepted) and a partial-clip check. `system/conventions.md` and docs 06, 07 and 08 updated                                                                                                                                                                                                                                                                                                                      |
| 1.16     | 2026-09-22 | Source 3 (Evergreen notes) ingested from the hub page. Its principle notes, the D-040 settings entry and one skill tweak are parked; doc 06 §6 lists them                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| 1.17     | 2026-09-22 | Source 4 (Contextual Retrieval) ingested, with the first real disagreement between sources recorded on both sides. D-047 proposed and accepted: `contested` belongs on the pages carrying the disputed claim, not on source pages or the overview. Docs 03, 06, 07 and 08 and the `ingest` skill updated                                                                                                                                                                                                                                                                                                                                                                                         |
| **1.18** | 2026-09-22 | **M3 closed.** Source 5 (The PARA Method) ingested: 6 existing pages updated, 3 with new cited claims, against a bar of 3, and a second disagreement recorded on both sides. Five sources in `raw/`, 26 wiki pages, 11 insight drafts. Doc 17 (M3 Handover) added; docs 00 and 06 updated                                                                                                                                                                                                                                                                                                                                                                                                        |
| **1.19** | 2026-09-24 | **M4 started.** `ask` and `file-answer` skills drafted (arrive as `ask-SKILL.md` and `file-answer-SKILL.md` for you to move into `.claude/skills/`) and mirrored in doc 08 §4.2–4.3; the ask section of `CLAUDE.md` becomes a pointer. Test prompts made concrete, `system/test-results.md` and the test 7 file drafted. D-048 to D-052 proposed. Docs 06, 07, 08 and 13 updated                                                                                                                                                                                                                                                                                                                 |
| **1.20** | 2026-09-24 | **M4 closed.** D-048 to D-052 accepted. Test run 1: 10 of 10. First analysis page filed; its re-check caught an unsupported claim on two concept pages, queued for `/lint`. Fix batch: fixed answer sections, recommendation rule (D-053, proposed), no installing when a tool is missing (D-054, proposed), unreadable raw files and Related links in `file-answer`. `CLAUDE.md`, both skills and `system/test-results.md` updated; docs 06, 07 and 08 updated; doc 18 (M4 Handover) added                                                                                                                                                                                                      |
| **1.21** | 2026-09-24 | **M5 started.** D-053 and D-054 accepted. `lint` skill drafted (arrives as `lint-SKILL.md` for you to move into `.claude/skills/lint/`) and mirrored in doc 08 §4.4: a report run that changes nothing in `wiki/`, and `/lint apply <numbers>` for the fixes you approve. `CLAUDE.md`'s lint section becomes a pointer, with two citation rules added. `system/views/Review.base` holds the two review views; the weekly review is written as steps in doc 05 §4. Lint tests L1–L6 added to doc 08 §5 and `system/test-results.md`. D-055 to D-059 proposed. Docs 04, 05, 06, 07, 08 and 13 updated                                                                                              |
| 1.22     | 2026-09-24 | D-055 to D-059 accepted. M5 files placed in the vault and pushed; the review views bookmarked and checked. First `/lint` run: 14 findings, L1–L4 pass. One finding (5) was wrong because the skill's analysis-page rule contradicted D-051, so `lint` and `file-answer` were reworded to match it. `system/test-results.md` updated; docs 05, 06, 07 and 08 updated                                                                                                                                                                                                                                                                                                                              |
| **1.23** | 2026-09-24 | **M5 exit met.** `/lint apply` made the 13 approved fixes; the second `/lint` checked only what changed and found 3 new, real problems. Lint tests 6 of 6. D-060 (monthly full deep check) and D-061 (a wrong PDF page is a Low finding) proposed, and `lint` revised to match. `system/test-results.md` and docs 05, 06, 07 and 08 updated                                                                                                                                                                                                                                                                                                                                                      |
| **1.24** | 2026-09-24 | **M5 closed.** D-060 and D-061 accepted. Second report's 3 fixes applied. MVP at 5 of 6 criteria; D-062 (proposed) moves the insights criterion to M6. Doc 19 (M5 Handover) added; docs 06 and 07 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| **1.25** | 2026-09-24 | **M6 started.** D-062 accepted. `drafts` skill drafted (arrives as `drafts-SKILL.md` for you to move into `.claude/skills/drafts/`) and mirrored in doc 08 §4.5: it checks drafts against `raw/` and writes its Check into each one, and lists insights to re-read. The drafts routine rewrites weekly review step 5: keeping a draft means writing your own page. Insight pages gain `reviewed`; `mine/decisions/` is separated from doc 07; `ingest` drafts now cite `raw/`. Drafts tests R1–R5 added. D-063 to D-067 proposed. `CLAUDE.md`, `system/conventions.md`, the Insight template, `Review.base` and `system/test-results.md` updated; docs 02, 03, 04, 05, 06, 07, 08 and 10 updated |
| 1.26     | 2026-09-25 | D-063 to D-067 accepted. M6 files placed and pushed. First `/drafts` run: all 11 drafts checked, 2 clean and 9 with problems. Every finding holds against `raw/`, and R1–R4 pass. `system/test-results.md` and docs 06 and 07 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| 1.27     | 2026-09-25 | MVP first, then a revision of the whole product before MVP 2 (Q-016 opened). D-068 proposed: Claude writes the five MVP insights from the checked drafts and you accept them; they stay `origin: claude`, and all 11 drafts are deleted. Docs 04, 06 and 07 updated                                                                                                                                                                                                                                                                                                                                                                                                                              |
| **1.28** | 2026-09-25 | **M6 closed; MVP complete, 6 of 6.** D-068 accepted; the five insights placed and the 11 drafts deleted. R5 passes, so drafts tests are 5 of 5. Q-016 answered with D-069: the next module is M7 – Retrospective and Revision, and the old M7 and M8 become candidates for MVP 2. Doc 20 (M6 Handover) added; docs 06, 07 and 08 and `system/test-results.md` updated; the Epics insight's `reviewed` date set back after R5                                                                                                                                                                                                                                                                     |
| **1.29** | 2026-09-25 | **Threads become standing.** D-070: the revision runs in the M0 thread, now M0 – Project Management. D-071: every module thread is the standing home of what its module owns, with an ownership map, request briefs and rules in doc 09 §4 (supersedes D-015). Doc 21 (MVP Retrospective) drafted with its record sections filled. Docs 06, 07, 08, 09 and 20 updated                                                                                                                                                                                                                                                                                                                            |
| **1.30** | 2026-09-25 | Doc 22 (Product Backlog) added, owned by M0; D-072 proposed. B-001 (Office documents as sources) and B-002 (Mermaid support) logged as New. Docs 07 and 09 updated                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               |
| 1.31     | 2026-09-26 | Doc 23 (Product Requirements) added: the whole system for a newcomer, built from docs 01–22 and the live vault files, with every diagram in Mermaid. D-073 accepted: every diagram is Mermaid. B-002 put on hold. Docs 07, 09 and 22 updated |
| 1.32     | 2026-09-26 | Doc 23 revised: §3 becomes User stories and end-to-end flow, with 13 user stories and the flow redrawn as one row per story through input, process, store and output. The folder map is redrawn top-down with its legend top-left, every diagram follows D-074, and wiki page status (§6.2) is now a table. D-074 accepted: rules for Mermaid diagrams. Docs 07 and 09 updated |
| 1.33     | 2026-09-26 | B-003 (Claude outputs as sources) logged in doc 22 as New, with options a to c |
| 1.34     | 2026-09-27 | D-075 accepted: Claude outputs can be sources, verified claim by claim at ingest (answers B-003 with option c). B-003 refined with the design for the source path. Docs 07 and 22 updated |
| 1.35     | 2026-09-30 | Doc 21 revised for MVP 2: your input in §4–§6, Claude's observations marked confirmed or open (§3.1), changes since the MVP closed (§3.2), and a new §7 with six themes, a candidate goal and build order, the tensions with current decisions, and 15 decisions MVP 2 needs. Two Mermaid diagrams added |
| **1.36** | 2026-09-30 | **Product vision and SDLC restructure.** Doc 10 (Product Vision) added: target group, needs, North Star and measures, milestones (S1 Showcase, MVP 2 to 4) and 9 capabilities. Doc 22 restructured by capability, with a Definition of Ready, types, MoSCoW, and B-004 to B-036 logged. The set renumbered by SDLC stage in blocks of ten, with every reference updated in the project docs, `CLAUDE.md`, the five skills and `system/` files; gaps listed in 00. Doc 02 gains the delivery framework (§11) and a new numbering rule. D-076 proposed; D-077 to D-080 accepted. Docs 00, 02, 03, 11, 20, 21 and 22 updated |
| 1.37     | 2026-09-30 | D-081 accepted: Release S1 (Showcase) comes next, before MVP 2, and research (MVP 2) and jobs (MVP 3) are separate milestones. Docs 03 and 10 updated |
| 1.38     | 2026-09-30 | D-082 accepted: no showcase after MVP 1, and a showcase gate at the end of every MVP; MVP 2 comes next. Q-017 opened: what makes the thinking layer worth showing. Docs 02, 03, 10 and 22 updated |
| 1.39     | 2026-09-30 | Q-017 answered with D-083: the showcase bar is a chat answer that beats a default Claude answer through its fact guarantee. B-004 refined to a cited research summary; B-037 (`/import`, duplicates and versions) logged. Docs 03, 10 and 22 updated |
| **1.40** | 2026-09-30 | **MVP 2 scoped.** D-084 accepted: Must, Should and Could items, success criteria in doc 11 §11, and modules M7 – Batch Ingest and Trust, M8 – Research and Import, M9 – Large Documents in doc 21. B-038 (large documents) logged. Doc 87 §8 filled. Old M7 and M8 references updated in docs 03, 11 and 30. Docs 02, 03, 10, 11, 21, 22, 30 and 87 updated |
| **1.41** | 2026-09-30 | **M7 started.** `ingest` reworked to take a set: one brief, one move block, one run, and one set review in `system/ingest/` with conflicts first and facts sorted by trust; `/ingest resolve` applies your decisions on conflicts. Trust levels (doc 31 §2.1) and the conflict review (doc 31 §3) drafted for M0. Claude commits after your review, with an ask rule on `git commit` and a deny rule on `git push`; log entries name pages. `CLAUDE.md`, `.claude/settings.json`, `system/conventions.md`, the Source template, the five skills and the six source pages updated. Tests I1–I7 on six UK regulation sources. D-085 to D-092 proposed. Docs 00, 03, 21, 22, 31, 32, 33, 40 and 70 and `system/test-results.md` updated |
| 1.42 | 2026-09-30 | D-085 to D-092 accepted, with doc 31 §2.1 (trust levels) and §3 (conflict review). D-008 revised by D-090. Docs 00, 03, 21, 22, 31, 33 and 40 updated |
| 1.43 | 2026-10-06 | Tests I1 (a set of one) and I2 (injection) pass. D-093 accepted: no personal-data flag; public material that names people is compiled like any other source, and the confidentiality stop stays. `ingest` revised after I1: where an open dispute sits, `sources` on pages that cite another raw file, conflict notes updated on resolve, one commit for an ingest and its resolve. `CLAUDE.md`, the `ingest` skill and `system/test-results.md` updated; docs 00, 03, 20, 21, 31 and 40 updated |
| **1.44** | 2026-10-06 | **M7 closed: tests I1–I7 pass, 7 of 7.** Five sources compiled in one run with one review (18 pages new, 10 updated, 58 facts), three conflicts decided, and `/ask` reports the trust level of each fact. Charter §11 criterion 3 met; D-022 replaced by D-085. D-094 accepted: at the same level, a body's own statement about itself is proposed before the newer source. `ingest` revised: press Enter after the move block, and no scripts on vault files. Doc 88 (M7 Handover) added, with the opening brief for M8 and a request for M0. `CLAUDE.md`, `system/conventions.md`, the `ingest` skill and `system/test-results.md` updated; docs 00, 03, 21, 22, 31, 33, 40 and 70 updated |
| **1.45** | 2026-10-06 | **M8 started.** Two new skills: `research`, which writes a report in `system/research/` where every fact names its source, with a link and a quote, and lists the sources to clip in `system/research/capture.md`; and `import`, which checks `inbox/sources/` against `raw/` for duplicates and newer versions and writes nothing. `ingest` extended: the import check in its brief, Claude outputs checked claim by claim through the supporting file `ai-source.md`, `· AI` claims re-cited when a later source states them, and capture lines ticked. The web is reached only from `/research`: its own grant for searches and official sites, no allow rule, five deny rules on shell routes. Tests IM1–IM4, RS1–RS4 and AI1–AI4 added. D-095 to D-100 proposed, with doc 31 §2.2. `CLAUDE.md`, `.claude/settings.json`, `system/conventions.md`, the `ingest`, `lint` and `ask` skills and `system/test-results.md` updated; docs 00, 03, 21, 22, 31, 32, 33 and 40 updated |
